// NOTE: Don't use this token, replace it with your own client access token.
$.jribbble.setToken('f688ac519289f19ce5cebc1383c15ad5c02bd58205cd83c86cbb0ce09170c1b4');

$.jribbble.users('tylergaw').shots({per_page: 36}).then(function(shots) {
  var html = [];
  
  shots.forEach(function(shot) {
    html.push('<div>');
    html.push('<a href="' + shot.html_url + '" target="_blank">');
    html.push('<img src="' + shot.images.normal + '">');
    html.push('</a></div>');
  });
  
  $('.gallery').html(html.join(''));
});