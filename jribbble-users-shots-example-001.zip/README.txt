A Pen created at CodePen.io. You can find this one at http://codepen.io/timothyblake/pen/qjXzVe.

 An example of using Jribbble to get a user's shots